const users = [
    {
        id: 1,
        name: '민지',
        gender: '여',
        major: '컴퓨터공학',
    },
    {
        id: 2,
        name: '하니',
        gender: '여',
        major: '전자공학',
    },
    {
        id: 3,
        name: '다니엘',
        gender: '여',
        major: '기계공학',
    },
    {
        id: 4,
        name: '해린',
        gender: '여',
        major: '화학공학',
    },
    {
        id: 5,
        name: '혜인',
        gender: '여',
        major: '건축공학',
    },
];
module.exports = users;
